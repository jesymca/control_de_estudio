<?php

$servidor = "localhost";
$usuario = "iutpc";
$clave = "6FyuTWvr6fPTeckl";
$base_datos = "pnfdiurno";

?>
